# Krunker-Cheat Injector
![IceHacks Logo](https://media.discordapp.net/attachments/622241766107774996/639570452234240020/unknown.png)


This is a working Krunker.io Cheat to be constantly updated by IceHacks and zbot473.

## Installation
- Download the [latest zip](https://github.com/IceHacks/KrunkerCheatInjector/releases/latest).
  - Expand "Assets"
  - Click "latest.zip"
- Extract the zip file
  - Open the zip and drag the contents into a new folder.
- Open up `chrome://extensions` in your chromium browser.
  - Make sure develpoer mode is enabled (top right)
- Load the extension
  - Drag the latest zip folder onto `chrome://extensions`
  - Or press "Load Unpacked" and find the folder in your file explorer
  
\* For any errors make sure you are using the right folder, check for subfolders.

## FAQ
> How do I open the cheat menu?

Just press "n" on krunker.io

> How do I make BHop work?

Hold "v"\* to use BHop.

> Something isn't working

Make sure it is enabled. If it is, refresh the page.


<sub>\* [Binds](#coming-soon)</sub>

## Features
- Aimbot
  - Aim Assist
  - Aim at head
- BHop
  - Auto jump
  - Auto crouch
- AutoSwitch
- AutoReload

### Coming soon
- Binds
- Saved settings
- More options

<sub>© 2019 IceHacks and zbot473</sub>
