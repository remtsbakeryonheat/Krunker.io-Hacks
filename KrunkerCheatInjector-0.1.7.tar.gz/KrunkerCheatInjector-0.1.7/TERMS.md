# TERMS AND CONDITIONS
### These are the terms for all my products.
Use of this product require the obeying of these written rules.

- reproduction of this product with claims to creation is not allowed
- duplication is not allowed
- production in videos is prohibited unless you have permission
- this product is not for retail sale or any other sale
- I am not responsible for the outcomes of your actions

basically this is mine and I am keeping it that way.
